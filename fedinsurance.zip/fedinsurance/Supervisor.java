package fedinsurance;


public class Supervisor {
	String supervisorID;
	String supervisorName;
	String position;
	Department department;
	
	public Supervisor Supervisor(String anID, String aName, String aPosition, Department aDepartment) {
		this.supervisorID = anID;
		this.supervisorName = aName;
		this.position = aPosition;
		this.department = aDepartment;
		return this;
	}
	
	public String getSupervisorID() {
		return this.supervisorID;
	}
	public void setSupervisorID(String anID) {
		this.supervisorID = anID ;
	}
	
	public String getSupervisorName() {
		return this.supervisorName;
	}
	public void setSupervisorName(String aName) {
		this.supervisorID = aName ;
	}
	
	public String getPosition() {
		return this.position;
	}
	public void setPosition(String aPosition) {
		this.position = aPosition ;
	}
	
	public Department getDepartment() {
		return this.department;
	}
	public void setDepartment(Department aDept) {
		this.department = aDept;
	}
	
}
