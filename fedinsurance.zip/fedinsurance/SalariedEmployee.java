package fedinsurance;

public class SalariedEmployee extends Employee {
	public Salary salary;
	//Constructor
	public Employee SalariedEmployee(String anemployeeID, String aposition, String anemployeeName, String anemployeeDepartment, Employee asupervisor, 
			 String areviewPeriod, String username, String password, Salary aWage) {
		
		setEmployeeID(anemployeeID);
		setPosition(aposition);
		setEmployeeName(anemployeeName);
		setEmployeeDepartment(anemployeeDepartment);
		setSupervisor(asupervisor);
		setReviewPeriod(areviewPeriod);
		setUsername(username);
		setPassword(password);	
		setSalary(aWage);
		return this;
	}
	
	public Salary getSalary() {
		return this.salary;
	}
	
	public void setSalary(Salary aWage) {
		this.salary = aWage;
	}

}

