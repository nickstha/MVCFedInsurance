package fedinsurance;

public class HourlyEmployee extends Employee {
	public int hourlywage;
	//Constructor
	public Employee HourlyEmployee(String anemployeeID, String aposition, String anemployeeName, String anemployeeDepartment, Employee asupervisor, 
			 String areviewPeriod, String username, String password, int aWage) {
		
		setEmployeeID(anemployeeID);
		setPosition(aposition);
		setEmployeeName(anemployeeName);
		setEmployeeDepartment(anemployeeDepartment);
		setSupervisor(asupervisor);
		setReviewPeriod(areviewPeriod);
		setUsername(username);
		setPassword(password);	
		setHourlyWage(aWage);
		return this;
	}
	
	public int getHourlywage() {
		return this.hourlywage;
	}
	
	public void setHourlyWage(int aWage) {
		this.hourlywage = aWage;
	}

}

