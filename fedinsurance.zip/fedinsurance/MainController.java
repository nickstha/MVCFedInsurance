package fedinsurance;

public class MainController {

	public static void main(String[] args) {
		Supervisor testSupervisor = new Supervisor()
		
		SalariedEmployee testEmployee = new SalariedEmployee("24", "Level 2 Software Developer", "Cal Capra", "Blue Department", supervisor, 
				 String areviewPeriod, String username, String password, Salary aWage);

	}

}
