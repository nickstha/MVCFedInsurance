package fedinsurance;

public class Performance {
	String performanceRank;
	
	public String getPerformanceRank() {
		return this.performanceRank;
	}
	public void setPerformanceRank(String aRank) {
		this.performanceRank = aRank;
	}
}
