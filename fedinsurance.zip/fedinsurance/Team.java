package fedinsurance;

public class Team {
	String teamID = "N/A";
	String teamName = "n/a";
	Employee supervisor;
	
	
	public String getTeamID() {
		return this.teamID;
	}
	public void setTeamID(String anID ) {
		this.teamID = anID ;
	}
	
	public String getTeamName() {
		return this.teamName;
	}
	public void setTeamName(String aName ) {
		this.teamName = aName ;
	}
	
	public Employee getSupervisor() {
		return this.supervisor;
	}
	public void setSupervisor(Employee aSupervisor ) {
		this.supervisor = aSupervisor ;
	}

}
