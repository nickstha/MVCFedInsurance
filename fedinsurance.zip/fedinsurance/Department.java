package fedinsurance;


public class Department {
	String deptID = "N/A";
	String deptName = "n/a";
	Employee supervisor;
	
	
	public String getDeptID() {
		return this.deptID;
	}
	public void setDeptID(String anID ) {
		this.deptID = anID ;
	}
	
	public String getDeptName() {
		return this.deptName;
	}
	public void setDeptName(String aName ) {
		this.deptName = aName ;
	}
	
	public Employee getSupervisor() {
		return this.supervisor;
	}
	public void setSupervisor(Employee aSupervisor ) {
		this.supervisor = aSupervisor ;
	}
}